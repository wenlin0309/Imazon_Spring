const fetch = require('node-fetch').default;
const fs = require('fs');

fetch('https://fakestoreapi.com/products')
  .then(response => response.json())
  .then(data => {
    // Write the data to a JSON file
    fs.writeFile('products.json', JSON.stringify(data), err => {
      if (err) throw err;
      console.log('Product data saved to products.json');
    });
  })
  .catch(error => {
    // Handle any errors here
    console.error(error);
  });
