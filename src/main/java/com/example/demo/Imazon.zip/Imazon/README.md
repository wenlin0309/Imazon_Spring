# Imazon

## Author: Winston Lin, Yinghui Sun, Kevin Yu

# Site: https://full-stack-imazon.netlify.app/
