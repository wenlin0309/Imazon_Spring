$(document).ready(function () {
    $(".name").click(function () {
        location.href = "/index.html";
    });

    const $sign_in_form = $("#sign_up_form");
    $sign_in_form.submit(function (e) {
        e.preventDefault();
        const findUser = ['userName','userRealName', 'password'];
        let userInfoHash = {};

        findUser.forEach((key) => {
            userInfoHash[key] = $(this).find(`input[name=${key}]`).val();
        });

        $.ajax({
            url: 'http://Shoppingweb-env.eba-nhrczsdw.us-east-1.elasticbeanstalk.com:5000' + '/html/imazon/Sign_up',
            method: 'POST',
            contentType: "application/json;",
            data: JSON.stringify(userInfoHash),
            success : function(result) {
                if(result.code == "200"){
                    alert('success');
                    console.log(result);
                }
                else{
                    alert('fail, try again');
                }
                display(result);
            },
            error : function() {
                console.log("ERROR: ");
            }
         })
            //.then(() => {
        //     alert('Success');
        //     location.assign('/index.html');
        // }, (response) => {
        //     alert(`ajax Fail\nuserName: ${userInfoHash['userName']}\npassword: ${userInfoHash['password']}`);
        //     console.log(response);
        // });
    });
});