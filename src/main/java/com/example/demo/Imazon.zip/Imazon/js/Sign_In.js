$(document).ready(function () {
    $(".name").click(function () {
        location.href = "/index.html";
    });

    const $sign_in_form = $("#sign_in_form");
    $sign_in_form.submit(function (e) {
        e.preventDefault();
        const findUser = ['userName', 'password'];
        let userInfoHash = {};

        alert( window.location + '/Sign_In');

        findUser.forEach((key) => {
            userInfoHash[key] = $(this).find(`input[name=${key}]`).val();
        });

        $.ajax({
            // url: window.location + '/Sign_In',
            url: 'http://Shoppingweb-env.eba-nhrczsdw.us-east-1.elasticbeanstalk.com:5000' + '/html/imazon/Sign_In',
            method: 'POST',
            contentType: "application/json",
            data: JSON.stringify(userInfoHash),
            success : function(result) {
                if(result.code == "200"){
                    alert('success');
                    console.log(result);
                }
                else{
                    alert('fail, try again');
                }
                display(result);
            },
            error : function() {
                console.log("ERROR: ");
            }
        });
        // then(() => {
        //     alert('Success');
        //     location.assign('/index.html');
        // }, (response) => {
        //     alert(`ajax Fail\n userName: ${userInfoHash['userName']}\nPassword: ${userInfoHash['password']}`);
        //     console.log(response);
        // });
    });
});